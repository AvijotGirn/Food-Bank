package edu.ucalgary.ensf409;

enum FoodType
{
    PRO, 
    GRA, 
    FV, 
    OTHER, 
    CAL
}

